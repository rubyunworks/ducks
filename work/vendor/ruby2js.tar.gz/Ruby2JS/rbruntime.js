function rb_true(v) {
  return (v != false && v != null)
}
